import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import syntaxtree.AllocationExpression;
import syntaxtree.AndExpression;
import syntaxtree.ArrayAllocationExpression;
import syntaxtree.ArrayAssignmentStatement;
import syntaxtree.ArrayLength;
import syntaxtree.ArrayLookup;
import syntaxtree.ArrayType;
import syntaxtree.AssignmentStatement;
import syntaxtree.Block;
import syntaxtree.BooleanType;
import syntaxtree.BracketExpression;
import syntaxtree.ClassDeclaration;
import syntaxtree.ClassExtendsDeclaration;
import syntaxtree.CompareExpression;
import syntaxtree.Expression;
import syntaxtree.ExpressionList;
import syntaxtree.ExpressionRest;
import syntaxtree.FalseLiteral;
import syntaxtree.FormalParameter;
import syntaxtree.FormalParameterList;
import syntaxtree.FormalParameterRest;
import syntaxtree.Goal;
import syntaxtree.Identifier;
import syntaxtree.IfStatement;
import syntaxtree.IntegerLiteral;
import syntaxtree.IntegerType;
import syntaxtree.MainClass;
import syntaxtree.MessageSend;
import syntaxtree.MethodDeclaration;
import syntaxtree.MinusExpression;
import syntaxtree.Node;
import syntaxtree.NotExpression;
import syntaxtree.PlusExpression;
import syntaxtree.PrimaryExpression;
import syntaxtree.PrintStatement;
import syntaxtree.Statement;
import syntaxtree.ThisExpression;
import syntaxtree.TimesExpression;
import syntaxtree.TrueLiteral;
import syntaxtree.Type;
import syntaxtree.TypeDeclaration;
import syntaxtree.VarDeclaration;
import syntaxtree.WhileStatement;
import visitor.GJDepthFirst;

public class VVisitor extends GJDepthFirst<MyType, HashMap<String, String>> {

    VTranslator translate;
    private String currClass;
    private String currMethod;
    private int tempCount;
    private int ifCount;
    private int whileCount;
    private int boundCount;
    private int ssCount;
    private int nullCount;
    private int indent;
    private boolean needsAlloc = false;

    public VVisitor(VTranslator translator) {
        this.translate = translator;
        currMethod = null;
        currClass = null;

        indent = 0;
        tempCount = 0;
        ifCount = 1;
        whileCount = 1;
        ssCount = 1;
        nullCount = 1;
        boundCount = 1;
    }

    /*
     * Goal
     * f0: MainClass()
     * f1: TypeDeclaration()*
     * f2: <EOF>
     */
    public MyType visit(Goal n, HashMap<String, String> arg) {

        if (n.f1.present()) {
            // print all present methods and classes
            for (Node no : n.f1.nodes) {
                printMT((TypeDeclaration) no, arg);
            }
        }
        n.f0.accept(this, arg); // MainClass()
        n.f1.accept(this, arg); // TypeDeclaration()*
        if (needsAlloc != false) {
            translate.addToOut("func AllocArray(size)");
            translate.addToOut("  bytes = MulS(size 4)");
            translate.addToOut("  bytes = Add(bytes 4)");
            translate.addToOut("  v = HeapAllocZ(bytes)");
            translate.addToOut("  [v] = size");
            translate.addToOut("  ret v");
        }
        // <EOF>
        return null;
    }

    /*
     * MainClass
     * f0: "class"
     * f1: Identifier()
     * f2: "{"
     * f3: "public"
     * f4: "static"
     * f5: "void"
     * f6: "main"
     * f7: "("
     * f8: "String"
     * f9: "["
     * f10: "]"
     * f11: Identifier()
     * f12: ")"
     * f13: "{"
     * f14: VarDeclaration()*
     * f15: Statement()*
     * f16: "}"
     * f17: "}"
     */
    public MyType visit(MainClass mc, HashMap<String, String> arg) {
        currClass = mc.f1.f0.toString();
        currMethod = mc.f6.toString();

        tempCount = 0;
        translate.addToOut("func Main()");
        indent();

        mc.f14.accept(this, arg);
        mc.f15.accept(this, arg);

        translate.addToOut(formatIndent("ret"));
        deIndent();
        translate.addToOut("");

        currClass = null;
        currMethod = null;
        return null;
    }

    /*
     * TypeDeclaration
     * f0: ClassDeclaration() | ClassExtendsDeclaration()
     */
    public MyType visit(TypeDeclaration d, HashMap<String, String> arg) {
        d.f0.choice.accept(this, arg);
        return null;
    }

    /*
     * ClassDeclaration
     * f0: "class"
     * f1: Identifier()
     * f2: "{"
     * f3: VarDeclaration()*
     * f4: MethodDeclaration()*
     * f5: "}"
     */
    public MyType visit(ClassDeclaration cd, HashMap<String, String> arg) {
        currClass = cd.f1.f0.toString();

        cd.f3.accept(this, arg);
        cd.f4.accept(this, arg);

        currMethod = null;
        currClass = null;
        return null;
    }

    /*
     * ClassExtendsDeclaration
     * f0: "class"
     * f1: Identifier()
     * f2: "extends"
     * f3: Identifier()
     * f4: "{"
     * f5: VarDeclarataion()*
     * f6: MethodDeclaration()*
     * f7: "}"
     */
    public MyType visit(ClassExtendsDeclaration ced, HashMap<String, String> arg) {
        currClass = ced.f1.f0.toString();

        ced.f5.accept(this, arg);
        ced.f6.accept(this, arg);

        currClass = null;
        currMethod = null;
        return null;
    }

    /*
     * VarDeclaration
     * f0: Type()
     * f1: Identifier()
     * f2: ";"
     */
    public MyType visit(VarDeclaration vd, HashMap<String, String> arg) {
        // No VarDeclaration in Vapor. No need to print
        return null;
    }

    /*
     * MethodDeclaration
     * f0: "public"
     * f1: Type()
     * f2: Identifier()
     * f3: "("
     * f4: FormalParameterList()?
     * f5: ")"
     * f6: "{"
     * f7: VarDeclaration()*
     * f8: Statement()*
     * f9: "return"
     * f10: Expression()
     * f11: ";"
     * f12: "}"
     */
    public MyType visit(MethodDeclaration md, HashMap<String, String> arg) {
        currMethod = md.f2.f0.toString();
        String params = "this";
        tempCount = 0;
        // Check if FPL exists, grab all params
        if (md.f4.present()) {
            FormalParameterList fp = (FormalParameterList) md.f4.node;
            params += " " + fp.f0.f1.f0.toString();
            for (Node n : fp.f1.nodes) {
                FormalParameterRest fpr = (FormalParameterRest) n;
                params += " " + fpr.f1.f1.f0.toString();
            }
        }
        // add method params
        translate.addToOut(formatIndent("func " + currClass + "." + currMethod + "(" + params + ")"));
        indent();

        md.f7.accept(this, arg);
        md.f8.accept(this, arg);

        MyType retVal = md.f10.f0.choice.accept(this, arg);
        String retStr = resExpr(retVal);
        translate.addToOut(formatIndent("ret" + (retVal == null ? " 0" : " " + retStr)));
        deIndent();
        translate.addToOut("");
        currMethod = null;
        return null;
    }

    /*
     * FormalParameterList
     * f0: FormalParameter()
     * f1: FormalParameterRest()*
     */
    public MyType visit(FormalParameterList fpl, HashMap<String, String> arg) {
        // Grabbing these in MethodDeclaration
        return null;
    }

    /*
     * FormalParameter
     * f0: Type()
     * f1: Identifier()
     */
    public MyType visit(FormalParameter fp, HashMap<String, String> arg) {
        // Grabbing these in MethodDeclaration
        return null;
    }

    /*
     * FormalParameterRest
     * f0: ","
     * f1: FormalParameter()
     */
    public MyType visit(FormalParameterRest fpr, HashMap<String, String> arg) {
        // Grabbing these in MethodDeclaration
        return null;
    }

    /*
     * Type
     * f0: ArrayType() | BooleanType() | Identifier()
     */
    public MyType visit(Type t, HashMap<String, String> arg) {
        return null;
    }

    /*
     * ArrayType
     * f0: "int"
     * f1: "["
     * f2: "]"
     */
    public MyType visit(ArrayType at, HashMap<String, String> arg) {
        return null;
    }

    /*
     * BooleanType
     * f0: "boolean"
     */
    public MyType visit(BooleanType bt, HashMap<String, String> arg) {
        return null;
    }

    /*
     * IntegerType
     * f0: "int"
     */
    public MyType visit(IntegerType it, HashMap<String, String> arg) {
        return null;
    }

    /*
     * Statement
     * f0: Block() | AssignmentStatement() | ArrayAssignmentStatement() |
     * IfStatement() | WhileStatement() | PrintStatement()
     */
    public MyType visit(Statement s, HashMap<String, String> arg) {
        s.f0.choice.accept(this, arg);
        return null;
    }

    /*
     * Block
     * f0: "{"
     * f1: Statement()*
     * f2: "}"
     */
    public MyType visit(Block b, HashMap<String, String> arg) {
        b.f1.accept(this, arg);
        return null;
    }

    /*
     * AssignmentStatement
     * f0: Identifier()
     * f1: "="
     * f2: Expression()
     * f3: ";"
     */
    public MyType visit(AssignmentStatement as, HashMap<String, String> arg) {

        String id = as.f0.f0.toString();
        Node choice = as.f2.f0.choice;
        // if instVar is being used within a method before anything
        if (choice instanceof PrimaryExpression pe && pe.f0.choice instanceof Identifier rhsId) {
            String rhs = rhsId.f0.toString();
            String rhsKey = resiKey(currClass, rhs, arg);
            String lhsKey = resiKey(currClass, id, arg);
            boolean rhsIsInstVar = rhsKey != null && rhsKey.contains(":instVariable:");
            boolean lhsIsInst = lhsKey != null && lhsKey.contains(":instVariable:");

            if (rhsIsInstVar && !lhsIsInst) {
                int offset = getiOffset(currClass, rhs, arg);
                translate.addToOut(formatIndent(id + " = [this+" + offset + "]"));
                return null;
            }
        }
        if (choice instanceof MessageSend ms) {
            String instKey = resiKey(currClass, id, arg);
            if (instKey != null && instKey.contains(":instVariable:")) {
                MyType expr = as.f2.f0.choice.accept(this, arg);
                if (expr == null) {
                    return null;
                }
                int offset = getiOffset(currClass, id, arg);
                translate.addToOut(formatIndent("[this+" + offset + "] = " + resExpr(expr)));
            } else {
                visitMessageSend(id, ms, arg);
            }
            return null;
        }

        MyType exprType = as.f2.f0.choice.accept(this, arg);
        if (exprType == null) {
            return null;
        }

        String instKey = resiKey(currClass, id, arg);
        if (instKey != null && instKey.contains(":instVariable:")) {
            int offset = getiOffset(currClass, id, arg);
            translate.addToOut(formatIndent("[this+" + offset + "] = " + resExpr(exprType)));
        } else {
            if (exprType.type.endsWith(")") && id.startsWith("t.")) {
                String val = resExpr(exprType);
                translate.addToOut(formatIndent(id + " = " + val));
            } else {
                translate.addToOut(formatIndent(id + " = " + exprType.type));
            }
        }
        return null;
    }

    private void visitMessageSend(String id, MessageSend ms, HashMap<String, String> arg) {
        MyType rec = ms.f0.f0.choice.accept(this, arg);

        String methodName = ms.f2.f0.toString();
        if (rec == null) {
            return;
        }

        if (!rec.type.equals("this")) {

            String nullLabel = "null" + nullCount++;
            translate.addToOut(formatIndent("if " + resExpr(rec) + " goto :" + nullLabel));
            indent();
            translate.addToOut(formatIndent("Error(\"null pointer\")"));
            deIndent();
            translate.addToOut(formatIndent(nullLabel + ":"));
        }

        String recClass = getReceiver(ms.f0, arg);
        int offset = getmOffset(recClass, methodName, arg);
        String vmtStr = newTemp();

        translate.addToOut(formatIndent(vmtStr + " = [" + resExpr(rec) + "]"));
        translate.addToOut(formatIndent(vmtStr + " = [" + vmtStr + "+" + offset + "]"));

        String args = rec.type;
        if (ms.f4.present()) {

            ExpressionList el = (ExpressionList) ms.f4.node;

            MyType val = el.f0.f0.choice.accept(this, arg);
            if (val != null) {
                args += " " + resExpr(val);
            }
            for (Node n : el.f1.nodes) {
                ExpressionRest er = (ExpressionRest) n;
                MyType rest = er.f1.f0.choice.accept(this, arg);
                if (rest != null) {
                    args += " " + resExpr(rest);
                }
            }
        }

        translate.addToOut(formatIndent(id + " = call " + vmtStr + "(" + args + ")"));
    }

    /*
     * ArrayAssignmentStatement
     * f0: Identifier()
     * f1: "["
     * f2: Expression()
     * f3: "]"
     * f4: "="
     * f5: Expression()
     * f6: ";"
     */
    public MyType visit(ArrayAssignmentStatement aas, HashMap<String, String> arg) {
        // XXX: Working on this
        String id = aas.f0.f0.toString();

        MyType index = aas.f2.f0.choice.accept(this, arg);
        if (index == null) {
            return null;
        }

        String ref;
        String instKey = resiKey(currClass, id, arg);
        if (instKey != null && instKey.contains(":instVariable:")) {
            int offset = getiOffset(currClass, id, arg);
            ref = newTemp();
            translate.addToOut(formatIndent(ref + " = [this+" + offset + "]"));
        } else {
            ref = id;
        }

        String nullLabel = "null" + nullCount++;
        translate.addToOut(formatIndent("if " + ref + " goto :" + nullLabel));
        indent();
        translate.addToOut(formatIndent("Error(\"null pointer\")"));
        deIndent();
        translate.addToOut(formatIndent(nullLabel + ":"));

        String b0 = newTemp();

        String boundsLabel = "bounds" + boundCount++;
        translate.addToOut(formatIndent(b0 + " = [" + ref + "]"));
        translate.addToOut(formatIndent(b0 + " = Lt(" + resExpr(index) + " " + b0 +
                ")"));
        translate.addToOut(formatIndent("if " + b0 + " goto :" + boundsLabel + ""));
        indent();
        translate.addToOut(formatIndent("Error(\"array index out of bounds\")"));
        deIndent();
        translate.addToOut(formatIndent(boundsLabel + ":"));

        translate.addToOut(formatIndent(b0 + " = MulS(" + resExpr(index) + " 4)"));
        translate.addToOut(formatIndent(b0 + " = Add(" + b0 + " " + ref + ")"));
        MyType expr = aas.f5.f0.choice.accept(this, arg);

        if (expr == null) {
            return null;
        }
        String exprStr = resExpr(expr);
        translate.addToOut(formatIndent("[" + b0 + "+4] = " + exprStr));
        return null;
    }

    /*
     * IfStatement
     * f0: "if"
     * f1: "("
     * f2: Expression()
     * f3: ")"
     * f4: Statement()
     * f5: "else"
     * f6: Statement()
     */
    public MyType visit(IfStatement is, HashMap<String, String> arg) {

        String label = "if" + ifCount++;
        String ieLabel = label + "_else";
        String endLabel = label + "_end";

        MyType cond = is.f2.f0.choice.accept(this, arg); // cond
        if (cond == null) {
            return null;
        }
        String condStr = resExpr(cond); // make a temp if needed
        translate.addToOut(formatIndent("if0 " + condStr + " goto :" + ieLabel));
        indent();
        is.f4.f0.choice.accept(this, arg); // then
        translate.addToOut(formatIndent("goto :" + endLabel));
        deIndent();
        translate.addToOut(formatIndent(ieLabel + ":"));
        indent();
        is.f6.f0.choice.accept(this, arg); // else
        deIndent();
        translate.addToOut(formatIndent(endLabel + ":"));
        return null;
    }

    /*
     * WhileStatement
     * f0: "while"
     * f1: "("
     * f2: Expression()
     * f3: ")"
     * f4: Statement()
     */
    public MyType visit(WhileStatement ws, HashMap<String, String> arg) {

        String label = "while" + whileCount++;

        String topLabel = label + "_top";
        String endLabel = label + "_end";

        translate.addToOut(formatIndent(topLabel + ":"));

        MyType cond = ws.f2.f0.choice.accept(this, arg);

        if (cond == null) {
            return null;
        }
        String condStr = resExpr(cond);
        translate.addToOut(formatIndent("if0 " + condStr + " goto :" + endLabel));
        indent();

        ws.f4.f0.choice.accept(this, arg);
        translate.addToOut(formatIndent("goto :" + topLabel));
        deIndent();
        translate.addToOut(formatIndent(endLabel + ":"));
        return null;
    }

    /*
     * PrintStatement
     * f0: "System.out.println"
     * f1: "("
     * f2: Expression()
     * f3: ")"
     * f4: ";"
     */
    public MyType visit(PrintStatement ps, HashMap<String, String> arg) {
        MyType t2 = ps.f2.f0.choice.accept(this, arg);
        if (t2 == null) {
            return null;
        }
        String t2Str = resExpr(t2);
        translate.addToOut(formatIndent("PrintIntS(" + t2Str + ")"));

        return null;
    }

    /*
     * Expression
     * f0: AndExpression() | CompareExpression() | PlusExpression() |
     * MinusExpression() | TimesExpression() | ArrayLookup() | ArrayLength() |
     * MessageSend() | PrimaryExpression()
     */
    public MyType visit(Expression e, HashMap<String, String> arg) {
        return e.f0.choice.accept(this, arg);
    }

    /*
     * AndExpression
     * f0: PrimaryExpression()
     * f1: "&&"
     * f2: PrimaryExpression()
     */
    public MyType visit(AndExpression ae, HashMap<String, String> arg) {
        String temp = newTemp();

        MyType t0 = getOp(ae.f0, arg);
        if (t0 == null) {
            return null;
        }
        String lhs = resExpr(t0);

        String label = "ss" + ssCount++;
        String ieLabel = label + "_else";
        String endLabel = label + "_end";

        translate.addToOut(formatIndent("if0 " + lhs + " goto :" + ieLabel));
        indent();

        MyType t2 = getOp(ae.f2, arg);
        if (t2 == null) {
            return null;
        }

        translate.addToOut(formatIndent(temp + " = " + t2.type));
        translate.addToOut(formatIndent("goto :" + endLabel));
        // deIndent();
        deIndent();
        translate.addToOut(formatIndent(ieLabel + ":"));
        indent();
        translate.addToOut(formatIndent(temp + " = 0"));
        deIndent();
        translate.addToOut(formatIndent(endLabel + ":"));

        return new MyType(temp);
    }

    /*
     * CompareExpression
     * f0: PrimaryExpression()
     * f1: "<"
     * f2: PrimaryExpression()
     */
    public MyType visit(CompareExpression ce, HashMap<String, String> arg) {
        MyType t0 = getOp(ce.f0, arg);
        MyType t2 = getOp(ce.f2, arg);
        if (t0 == null || t2 == null) {
            return null;
        }
        String lhs = resExpr(t0);
        String rhs = resExpr(t2);
        return new MyType("LtS(" + lhs + " " + rhs + ")");
    }

    /*
     * PlusExpression
     * f0: PrimaryExpression()
     * f1: "+"
     * f2: PrimaryExpression()
     */
    public MyType visit(PlusExpression pe, HashMap<String, String> arg) {
        MyType t0 = getOp(pe.f0, arg);
        MyType t2 = getOp(pe.f2, arg);
        if (t0 == null || t2 == null) {
            return null;
        }

        return new MyType("Add(" + resExpr(t0) + " " + resExpr(t2) + ")");
    }

    /*
     * MinusExpression
     * f0: PrimaryExpression()
     * f1: "-"
     * f2: PrimaryExpression()
     */
    public MyType visit(MinusExpression me, HashMap<String, String> arg) {
        MyType t0 = getOp(me.f0, arg);
        MyType t2 = getOp(me.f2, arg);
        if (t0 == null || t2 == null) {
            return null;
        }
        return new MyType("Sub(" + resExpr(t0) + " " + resExpr(t2) + ")");
    }

    /*
     * TimesExpression
     * f0: PrimaryExpression()
     * f1: "*"
     * f2: PrimaryExpression()
     */
    public MyType visit(TimesExpression te, HashMap<String, String> arg) {
        MyType t0 = getOp(te.f0, arg);
        MyType t2 = getOp(te.f2, arg);
        if (t0 == null || t2 == null) {
            return null;
        }
        return new MyType("MulS(" + resExpr(t0) + " " + resExpr(t2) + ")");
    }

    /*
     * ArrayLookup
     * f0: PrimaryExpression()
     * f1: "["
     * f2: PrimaryExpression()
     * f3: "]"
     */
    public MyType visit(ArrayLookup al, HashMap<String, String> arg) {
        // FIXME: Working on
        MyType arr = getOp(al.f0, arg);
        MyType index = al.f2.f0.choice.accept(this, arg);
        if (arr == null || index == null)
            return null;

        String nullLabel = "null" + nullCount++;
        String boundsLabel = "bounds" + boundCount++;

        translate.addToOut(formatIndent("if " + resExpr(arr) + " goto :" + nullLabel));
        indent();
        translate.addToOut(formatIndent("Error(\"null pointer\")"));
        deIndent();
        translate.addToOut(formatIndent(nullLabel + ":"));

        String b0 = newTemp();
        translate.addToOut(formatIndent(b0 + " = [" + resExpr(arr) + "]"));
        translate.addToOut(formatIndent(b0 + " = Lt(" + resExpr(index) + " " + b0 + ")"));
        translate.addToOut(formatIndent("if " + b0 + " goto :" + boundsLabel));
        indent();
        translate.addToOut(formatIndent("Error(\"array index out of bounds\")"));
        deIndent();
        translate.addToOut(formatIndent(boundsLabel + ":"));

        // calc address and load the value

        translate.addToOut(formatIndent(b0 + " = MulS(" + resExpr(index) + " 4)"));
        translate.addToOut(formatIndent(b0 + " = Add(" + b0 + " " + resExpr(arr) + ")"));
        return new MyType("[" + b0 + "+4]");
    }

    /*
     * ArrayLength
     * f0: PrimaryExpression()
     * f1: "."
     * f2: "length"
     */
    public MyType visit(ArrayLength al, HashMap<String, String> arg) {
        // TODO:
        MyType t0 = al.f0.f0.choice.accept(this, arg);
        String nullLabel = "null" + nullCount++;
        translate.addToOut(formatIndent("if " + resExpr(t0) + " goto :" + nullLabel + ""));
        indent();
        translate.addToOut(formatIndent("Error(\"null pointer\")"));
        deIndent();
        translate.addToOut(formatIndent(nullLabel + ":"));
        String temp = newTemp();
        translate.addToOut(formatIndent(temp + " = [" + resExpr(t0) + "]"));
        return new MyType(temp);
    }

    /*
     * MessageSend
     * f0: PrimaryExpression()
     * f1: "."
     * f2: Identifier()
     * f3: "("
     * f4: ExpressionList()?
     * f5: ")"
     */
    public MyType visit(MessageSend ms, HashMap<String, String> arg) {
        // XXX: WORKING ON
        MyType rec = ms.f0.f0.choice.accept(this, arg);
        String methodName = ms.f2.f0.toString();
        if (rec == null) {
            return null;
        }

        // no null check needed for "this"
        if (!rec.type.equals("this")) {
            String nullLabel = "null" + nullCount++;
            translate.addToOut(formatIndent("if " + resExpr(rec) + " goto :" + nullLabel));
            indent();
            translate.addToOut(formatIndent("Error(\"null pointer\")"));
            deIndent();
            translate.addToOut(formatIndent(nullLabel + ":"));
        }

        String recClass = getReceiver(ms.f0, arg);
        int offset = getmOffset(recClass, methodName, arg);

        String vmtStr = newTemp();
        translate.addToOut(formatIndent(vmtStr + " = [" + resExpr(rec) + "]"));
        translate.addToOut(formatIndent(vmtStr + " = [" + vmtStr + "+" + offset + "]"));

        String args = rec.type;

        if (ms.f4.present()) {
            ExpressionList el = (ExpressionList) ms.f4.node;
            MyType val = el.f0.f0.choice.accept(this, arg);
            if (val != null) {
                args += " " + resExpr(val);
            }
            for (Node n : el.f1.nodes) {
                ExpressionRest er = (ExpressionRest) n;
                MyType rest = er.f1.f0.choice.accept(this, arg);
                if (rest != null) {
                    args += " " + resExpr(rest);
                }
            }
        }

        String res = newTemp();
        translate.addToOut(formatIndent(res + " = call " + vmtStr + "(" + args + ")"));
        String mk = resmKey(recClass, methodName, arg);
        if (mk == null) {
            return null;
        }
        return new MyType(res);
    }

    /*
     * ExpressionList
     * f0: Expression()
     * f1: ExpressionRest()
     */
    public MyType visit(ExpressionList el, HashMap<String, String> arg) {
        return null;
    }

    /*
     * ExpressionRest
     * f0: ","
     * f1: Expression()
     */
    public MyType visit(ExpressionRest er, HashMap<String, String> arg) {
        return null;
    }

    /*
     * PrimaryExpression()
     * f0: IntegerLiteral() | TrueLiteral() | FalseLiteral() | Identifier() |
     * ThisExpression() | ArrayAllocationExpression() | AllocationExpression() |
     * NotExpression() | BracketExpression()
     */
    public MyType visit(PrimaryExpression pe, HashMap<String, String> arg) {
        return pe.f0.choice.accept(this, arg);
    }

    /*
     * IntegerLiteral
     * f0: <INTEGER_LITERAL>
     */
    public MyType visit(IntegerLiteral il, HashMap<String, String> arg) {
        return new MyType(il.f0.toString());
    }

    /*
     * TrueLiteral
     * f0: "true"
     */
    public MyType visit(TrueLiteral tl, HashMap<String, String> arg) {
        return new MyType("1");
    }

    /*
     * FalseLiteral
     * f0: "false"
     */ public MyType visit(FalseLiteral fl, HashMap<String, String> arg) {
        return new MyType("0");
    }

    /*
     * Identifier
     * f0: <IDENTIFIER>
     */

    public MyType visit(Identifier id, HashMap<String, String> arg) {
        String name = id.f0.toString();
        String instKey = resiKey(currClass, name, arg);
        if (instKey != null && instKey.contains(":instVariable:")) {

            int offset = getiOffset(currClass, name, arg);
            String temp = newTemp();
            translate.addToOut(formatIndent(temp + " = [this+" + offset + "]"));
            return new MyType(temp);
        }
        return new MyType(name);
    }

    /*
     * ThisExpression
     * f0: "this"
     */
    public MyType visit(ThisExpression te, HashMap<String, String> arg) {
        return new MyType("this");
    }

    /*
     * ArrayAllocationExpression
     * f0: "new"
     * f1: "int"
     * f2: "["
     * f3: Expression()
     * f4: "]"
     */
    public MyType visit(ArrayAllocationExpression aae, HashMap<String, String> arg) {
        MyType t3 = getOp(aae.f3, arg);
        if (t3 == null) {
            return null;
        }
        needsAlloc = true;
        String res = newTemp();
        translate.addToOut(formatIndent(res + " = call :AllocArray(" + t3.type + ")"));
        return new MyType(res);
    }

    /*
     * AllocationExpression
     * f0: "new"
     * f1: Identifier()
     * f2: "("
     * f3: ")"
     */
    public MyType visit(AllocationExpression ae, HashMap<String, String> arg) {
        String className = ae.f1.f0.toString();

        if (!arg.containsKey(classKey(className))) {
            return null;
        }

        int allocSize = getAllocationSize(className, arg);
        String temp = newTemp();
        translate.addToOut(formatIndent(temp + " = HeapAllocZ(" + allocSize + ")"));

        translate.addToOut(formatIndent("[" + temp + "] = :vmt_" + className));

        return new MyType(temp);
    }

    /*
     * NotExpression
     * f0: "!"
     * f1: Expression()
     */
    public MyType visit(NotExpression ne, HashMap<String, String> arg) {
        MyType exprType = ne.f1.f0.choice.accept(this, arg);
        if (exprType == null) {
            return null;
        }
        String in = resExpr(exprType);
        // String temp = newTemp();
        return new MyType("Sub(1 " + in + ")");
    }

    /*
     * BracketExpression
     * f0: "("
     * f1: Expression()
     * f2: ")"
     */
    public MyType visit(BracketExpression be, HashMap<String, String> arg) {
        return be.f1.f0.choice.accept(this, arg);
    }

    /********************* HELPER METHODS *****************/

    /************** FORMATTING ************/

    private String formatIndent(String message) {
        String ret = "";
        for (int i = 0; i < indent; i++) {
            ret += "  ";
        }
        ret += message;
        return ret;
    }

    private String stripKey(String k) {
        return k.substring(k.lastIndexOf('[') + 1, k.lastIndexOf(']'));
    }

    private String newTemp() {
        return "t." + tempCount++;
    }

    private void indent() {
        indent++;
    }

    private void deIndent() {
        indent--;
    }

    private void printMT(TypeDeclaration td, HashMap<String, String> arg) {
        String className;
        List<MethodDeclaration> methods = new ArrayList<>();
        if (td.f0.choice instanceof ClassDeclaration cd) {
            className = cd.f1.f0.toString();
            for (Node n : cd.f4.nodes) {
                methods.add((MethodDeclaration) n);
            }
        } else {
            ClassExtendsDeclaration ced = (ClassExtendsDeclaration) td.f0.choice;
            className = ced.f1.f0.toString();
            for (Node n : ced.f6.nodes) {
                methods.add((MethodDeclaration) n);
            }
        }
        translate.addToOut("");
        translate.addToOut("const vmt_" + className);
        for (MethodDeclaration m : methods) {
            String mName = m.f2.f0.toString();
            translate.addToOut("  :" + className + "." + mName);
        }
    }

    private int getAllocationSize(String name, HashMap<String, String> arg) {
        int count = 0;
        String curr = name;
        while (curr != null && !curr.equals("none")) {
            for (String k : arg.keySet()) {
                if (k.startsWith("class:[" + curr + "]:instVariable:[")) {
                    count++;
                }
            }
            String pk = parentClassKey(curr);
            curr = arg.containsKey(pk) ? arg.get(pk) : null; // make sure parent key exists before setting
        }
        return (count + 1) * 4;
    }

    private int getmOffset(String className, String methodName, HashMap<String, String> arg) {
        int offset = 0;
        String curr = className;
        while (curr != null && !curr.equals("none")) {
            for (String k : arg.keySet()) {
                if (k.startsWith("class:[" + curr + "]:method:[") && k.endsWith("]") && arg.get(k).equals("method")) {
                    if (stripKey(k).equals(methodName)) {
                        return offset;
                    }
                    offset += 4;
                }
            }
            String pk = parentClassKey(curr);
            curr = arg.containsKey(pk) ? arg.get(pk) : null;
        }
        return 0;
    }

    private int getiOffset(String className, String varName, HashMap<String, String> arg) {
        int offset = 4;
        String curr = className;
        while (curr != null && !curr.equals("none")) {
            for (String k : arg.keySet()) {
                if (k.startsWith("class:[" + curr + "]:instVariable:[")) {
                    if (stripKey(k).equals(varName)) {
                        return offset;
                    }
                    offset += 4;
                }
            }
            String pk = parentClassKey(curr);
            curr = arg.containsKey(pk) ? arg.get(pk) : null;
        }
        return 0;
    }

    /************** CHOICES ************/

    private String getReceiver(PrimaryExpression pe, HashMap<String, String> arg) {
        Node choice = pe.f0.choice;
        if (choice instanceof ThisExpression) {
            return currClass;
        } else if (choice instanceof AllocationExpression ae) {
            return ae.f1.f0.toString();
        } else if (choice instanceof Identifier id) {
            String name = id.f0.toString();
            if (currClass != null && currMethod != null) {
                String key = localKey(currClass, currMethod, name);
                if (arg.containsKey(key))
                    return arg.get(key);
                key = mParamKey(currClass, currMethod, name);
                if (arg.containsKey(key))
                    return arg.get(key);
            }
            String instKey = resiKey(currClass, name, arg);
            if (instKey != null) {
                return arg.get(instKey);
            }
        }
        return currClass;
    }

    private MyType getOp(Expression e, HashMap<String, String> arg) {
        return e.f0.choice.accept(this, arg);
    }

    private MyType getOp(PrimaryExpression p, HashMap<String, String> arg) {
        return p.f0.choice.accept(this, arg);
    }

    private String resiKey(String className, String var, HashMap<String, String> arg) {
        String curr = className;
        while (curr != null && !curr.equals("none")) {
            String key = instVarKey(curr, var);
            if (arg.containsKey(key))
                return key;
            String pk = parentClassKey(curr);
            curr = arg.containsKey(pk) ? arg.get(pk) : null;
        }
        return null;
    }

    private String resmKey(String className, String methodName, HashMap<String, String> arg) {
        String curr = className;
        while (curr != null && !curr.equals("none")) {
            String key = methodKey(curr, methodName);
            if (arg.containsKey(key)) {
                return key;
            }
            String pk = parentClassKey(curr);
            curr = arg.containsKey(pk) ? arg.get(pk) : null;
        }
        return null;
    }

    private String resExpr(MyType expr) {
        if (expr.type.endsWith(")") || expr.type.startsWith("[")) {
            String temp = newTemp();
            translate.addToOut(formatIndent(temp + " = " + expr.type));
            return temp;
        }
        return expr.type;
    }

    /************** KEY FORMATTING ************/

    private String classKey(String className) {
        return "class:[" + className + "]";
    }

    private String parentClassKey(String pcName) {
        return classKey(pcName) + ":parent";
    }

    private String methodKey(String className, String methodName) {
        return classKey(className) + ":method:[" + methodName + "]";
    }

    private String mParamKey(String className, String methodName, String paramName) {
        return methodKey(className, methodName) + ":methodParam:[" + paramName + "]";
    }

    private String localKey(String className, String methodName, String paramName) {
        return methodKey(className, methodName) + ":localParams:[" + paramName + "]";
    }

    private String instVarKey(String className, String varName) {
        return classKey(className) + ":instVariable:[" + varName + "]";
    }
}