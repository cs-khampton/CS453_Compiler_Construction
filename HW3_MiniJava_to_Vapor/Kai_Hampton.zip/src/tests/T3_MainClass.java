/* Rules used: r0, r1, r6, r25, r32 r61 */
// r0
class Factorial {
    public static void main(String[] arg) { // r1, r61
        int i; // r6
        i = i + 2; // r25, r32
    }
}